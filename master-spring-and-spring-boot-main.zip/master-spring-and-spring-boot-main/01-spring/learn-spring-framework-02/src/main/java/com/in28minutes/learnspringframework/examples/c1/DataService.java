package com.in28minutes.learnspringframework.examples.c1;

public interface DataService {
	int[] retrieveData();
}
