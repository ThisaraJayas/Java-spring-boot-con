package com.in28minutes.learnspringframework;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LearnSpringFrameworkApplicationTests {

	@Test
	void contextLoads() {
	}

}
